please follow the given steps: 
1. bundle install 
2. ruby lib/start.rb
3. Enter 10 digit phone number and hit enter.