require 'byebug'
class Conversion
  attr_reader :phone_number, :digit_to_chars
  attr_accessor :correct_words
  
  def initialize(phone_number)
    @phone_number = phone_number
    @digit_to_chars = { '2' => %w[A B C],
        '3' => %w[D E F],
        '4' => %w[G H I],
        '5' => %w[J K L],
        '6' => %w[M N O],
        '7' => %w[P Q R S],
        '8' => %w[T U V],
        '9' => %w[W X Y Z] }
    @correct_words = []
  end 
  
  def number_to_multiple_combinations
    number_to_words_combinations
    fetch_combinations
    @correct_words = @correct_words.uniq.reject { |x| x.join.length < 10 if x.is_a?(Array) || x.length < 10 }
    @correct_words = @correct_words.map{ |x| x.is_a?(Array) ? x.join(', ') : x }
    return @correct_words
  end

  
  def number_to_words_combinations
    return unless valid_phone_number?

    parse_dictionary
    extract_words
  end

  def valid_phone_number?
    return false if phone_number.nil?
    @phone_number = phone_number.gsub(/[^2-9]/, '') # select digits only 2 to 9. Ignore 0 and 1
    return true if @phone_number.length == 10
  end
  
  def parse_dictionary
    @dictionary = []
    File.foreach(Dir.pwd + '/dictionary.txt') do |word|
      @dictionary << word.strip
    end
  end
  
  def extract_words
    length = @phone_number.length
    i = 2
    @phone_keys = @phone_number.chars.map { |n| @digit_to_chars[n] }

    while i < (length - 3) # loop will run till i = 6
      phone_chars1 = @phone_keys[0..i]
      phone_chars2 = @phone_keys[(i + 1)..(length - 1)]
      get_correct_words([phone_chars1, phone_chars2])
      i += 1
    end
  end

  def get_correct_words(phone_chars_array)
    matches = []
    phone_chars_array.each do |phone_chars|
      # Now combine characters and create possible words.
      possible_words = phone_chars.shift.product(*phone_chars).map(&:join)

      # remove words with less than 3 chars
      possible_words.reject! { |x| x.length < 3 }

      # Match / Intersection of possible words with @dictionary array
      matches << (possible_words & @dictionary)
    end

    return if matches.any?(&:empty?)

    # Making combinations from above output
    if matches.size == 2
      @correct_words += matches[0].product(matches[1])
    elsif matches.size == 3
      @correct_words += matches[0].product(matches[1]).product(matches[2]).map(&:flatten)
    end
  end

  def fetch_combinations
    # Fetch from combinations 3+3+4, 3+4+3, 4+3+3
    get_correct_words([@phone_keys[0..2], @phone_keys[3..5], @phone_keys[6..9]])
    get_correct_words([@phone_keys[0..2], @phone_keys[3..6], @phone_keys[7..9]])
    get_correct_words([@phone_keys[0..3], @phone_keys[4..6], @phone_keys[7..9]])

    # it should be in last as it's shifting @phone_keys
    @correct_words << (@phone_keys.shift.product(*@phone_keys).map(&:join) & @dictionary).join(', ')
  end
  

end