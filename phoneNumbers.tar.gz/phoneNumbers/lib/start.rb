require_relative './conversion.rb'
puts 'Please enter the 10 digit mobile number :'
phone_number = gets.chomp
val = Conversion.new(phone_number)
puts val.number_to_multiple_combinations